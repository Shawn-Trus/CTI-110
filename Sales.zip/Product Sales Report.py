# Product Sales Report
# March 1 2018
# CSC121-0001 Product Sales Report
# Shawn Trusdell
#

def main():
    print("Item #      Customer Name          Item Description      Price")
    # Set variables for code starting with list 
    lines = []
    #Next for conversion of str to float
    num = []
    #setting base for total
    total = 0
    #Openning file and setup for a "for" statment to grab str splice 
    with open ('Sales.txt', 'rt') as in_file:
        for line in in_file:
            #Item Number
            x = line[7:10]
            w = line[10:13]
            #Customer Name
            y = line[13:32]
            #Item Description
            z = line[33:48]
            #Grab price 
            m = line[77:78]
            n = line[78:81]
            print(x + '-' + w + "     " + y + "     " + z + "      " + "$" + m + '.' + n)
            #convert str to float and add it to list called NUM
            a = float(m + n)
            price = a/100
            num.append(price)
    #gathering the total of all values that were added to NUM
    for value in num:
        value = float(price)
        total += value
    #gathering Average price 
    average = total / len(num)
    #Separating list from totals
    print("-"*45)
    # printing total and formatting to the 2 decimal place 
    print("The total of the item list is: ", '${:.2f}'.format(total))
    # printing average and formatting to the 2 decimal place w/ dollar sign
    print("The Average price of the items is: ", '${:.2f}'.format(average))   
main()
