# World Series
# Feb 20 2018
# CSC121-0001 PE10-World Series Champions
# Shawn Trusdell
#

def main():
    infile = open('World_Series.txt', 'r')
    teams = infile.readlines()
    infile.close()

    index = 0
    
    while index < len(teams):
        teams[index] = teams[index].rstrip('\n')
        index += 1
    
    search = input('Enter team: ')

    if search in teams:
        print (search, 'was found', teams.count(search), 'times')
    
    else:
        print (search, 'was not found')

    choice = input('Would you like to search for another team? [y/n]')

    if choice.lower()=='y':
        main()
    elif choice.lower()=='n':
        print ('Goodbye')

main()
